package com.mycompany.quickchat;

import javax.swing.JOptionPane;
import java.util.List;

/**
 * Main application for PROG5121 POE Part 3 – QuickChat.
 * Flow: Register → Login → Menu (Send / Recent / Management / Reports / Quit)
 */
public class QuickChat {

    public static void main(String[] args) {
        Login login = new Login();

        // ========== REGISTRATION ==========
        String firstName = JOptionPane.showInputDialog(null, "Please enter your first name");
        String lastName = JOptionPane.showInputDialog(null, "Please enter your last name");

        String username;
        do {
            username = JOptionPane.showInputDialog(null,
                    "Enter username (must contain _ and be ≤ 5 characters):");
            if (username == null) {
                return;
            }
            if (!login.checkUserName(username)) {
                JOptionPane.showMessageDialog(null,
                        "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
            }
        } while (!login.checkUserName(username));

        String password;
        do {
            password = JOptionPane.showInputDialog(null,
                    "Enter password (≥ 8 chars, capital, number, special character):");
            if (password == null) {
                return;
            }
            if (!login.checkPasswordComplexity(password)) {
                JOptionPane.showMessageDialog(null,
                        "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
            }
        } while (!login.checkPasswordComplexity(password));

        String cell;
        do {
            cell = JOptionPane.showInputDialog(null,
                    "Enter cell number (0 + 9 digits or +27 + 9 digits):");
            if (cell == null) {
                return;
            }
            if (!login.checkCellPhoneNumber(cell)) {
                JOptionPane.showMessageDialog(null,
                        "Cell phone number incorrectly formatted or does not contain an international code, please correct the number and try again.");
            }
        } while (!login.checkCellPhoneNumber(cell));

        String regMsg = login.registerUser(username, password, firstName, lastName, cell);
        JOptionPane.showMessageDialog(null, regMsg);

        // ========== LOGIN ==========
        String loginUser = JOptionPane.showInputDialog(null, "Enter username to login:");
        String loginPass = JOptionPane.showInputDialog(null, "Enter password to login:");
        if (loginUser == null || loginPass == null) {
            return;
        }

        String loginStatus = login.returnLoginStatus(loginUser, loginPass);
        JOptionPane.showMessageDialog(null, loginStatus);

        if (!login.loginUser(loginUser, loginPass)) {
            return;
        }

        // ========== PART 3 MENU ==========
        MessageStorage.initializeStorage();
        String senderName = login.getFirstName() + " " + login.getLastName();
        boolean running = true;

        while (running) {
            String option = JOptionPane.showInputDialog(null,
                    "Welcome to QuickChat.\n"
                            + "1) Send Messages\n"
                            + "2) Show recently sent messages\n"
                            + "3) Message Management\n"
                            + "4) Display Reports\n"
                            + "5) Quit");

            if (option == null) {
                break;
            }

            switch (option.trim()) {
                case "1" -> handleSendMessages(senderName);
                case "2" -> JOptionPane.showMessageDialog(null, MessageStorage.getRecentMessages());
                case "3" -> handleMessageManagement();
                case "4" -> handleReports(senderName);
                case "5" -> running = false;
                default -> JOptionPane.showMessageDialog(null, "Invalid option.");
            }
        }
    }

    private static void handleSendMessages(String senderName) {
        try {
            String numStr = JOptionPane.showInputDialog(null, "How many messages do you want to send?");
            if (numStr == null) {
                return;
            }
            int numMessages = Integer.parseInt(numStr.trim());

            for (int i = 1; i <= numMessages; i++) {
                String recipient = JOptionPane.showInputDialog(null,
                        "Enter recipient number (+27...):");
                if (recipient == null) {
                    continue;
                }
                if (!Message.checkRecipientCell(recipient)) {
                    JOptionPane.showMessageDialog(null,
                            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.");
                    continue;
                }

                String text = JOptionPane.showInputDialog(null,
                        "Enter your message (max 250 characters):");
                if (text == null) {
                    continue;
                }

                Message msg = new Message(recipient, text);
                String lengthCheck = msg.checkMessageLength();
                if (!lengthCheck.equals("Message ready to send.")) {
                    JOptionPane.showMessageDialog(null, lengthCheck);
                    continue;
                }

                String actionStr = JOptionPane.showInputDialog(null,
                        "Choose:\n1) Send Message\n2) Disregard Message\n3) Store Message");
                if (actionStr == null) {
                    continue;
                }
                int action = Integer.parseInt(actionStr.trim());
                String result = msg.sentMessage(action);
                JOptionPane.showMessageDialog(null, result);

                MessageStorage.storeMessage(msg, action);
                JOptionPane.showMessageDialog(null, msg.printMessages());
            }

            JOptionPane.showMessageDialog(null,
                    "Total messages sent: " + Message.returnTotalMessages());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a valid number.");
        }
    }

    private static void handleMessageManagement() {
        String option = JOptionPane.showInputDialog(null,
                "Message Management:\n"
                        + "1) Search by Message ID\n"
                        + "2) Search by Recipient\n"
                        + "3) Delete by Hash\n"
                        + "4) Back");

        if (option == null) {
            return;
        }

        switch (option.trim()) {
            case "1" -> {
                String id = JOptionPane.showInputDialog(null, "Enter Message ID:");
                if (id == null) {
                    return;
                }
                Message found = MessageStorage.searchByMessageId(id.trim());
                if (found != null) {
                    JOptionPane.showMessageDialog(null,
                            "Message Found:\n" + found.printMessages());
                } else {
                    JOptionPane.showMessageDialog(null, "Message not found with ID: " + id);
                }
            }
            case "2" -> {
                String recipient = JOptionPane.showInputDialog(null, "Enter recipient number:");
                if (recipient == null) {
                    return;
                }
                List<Message> list = MessageStorage.searchByRecipient(recipient.trim());
                if (list.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No messages found for recipient: " + recipient);
                } else {
                    StringBuilder sb = new StringBuilder("Messages for " + recipient + ":\n\n");
                    for (Message m : list) {
                        sb.append(m.printMessages()).append("\n---\n");
                    }
                    JOptionPane.showMessageDialog(null, sb.toString());
                }
            }
            case "3" -> {
                String hash = JOptionPane.showInputDialog(null, "Enter message hash to delete:");
                if (hash == null) {
                    return;
                }
                boolean deleted = MessageStorage.deleteByHash(hash.trim());
                if (deleted) {
                    JOptionPane.showMessageDialog(null, "Message with hash " + hash + " deleted successfully.");
                } else {
                    JOptionPane.showMessageDialog(null, "Message not found with hash: " + hash);
                }
            }
            default -> {
                // back
            }
        }
    }

    private static void handleReports(String senderName) {
        String option = JOptionPane.showInputDialog(null,
                "Reports:\n"
                        + "1) Sender/Recipient of Sent Messages\n"
                        + "2) Longest Sent Message\n"
                        + "3) Full Report\n"
                        + "4) Back");

        if (option == null) {
            return;
        }

        switch (option.trim()) {
            case "1" -> JOptionPane.showMessageDialog(null,
                    MessageStorage.displaySenderRecipient(senderName));
            case "2" -> JOptionPane.showMessageDialog(null,
                    MessageStorage.displayLongestMessage());
            case "3" -> JOptionPane.showMessageDialog(null,
                    MessageStorage.displayFullReport(senderName));
            default -> {
                // back
            }
        }
    }
}
