package com.mycompany.quickchat;

/**
 * Login / authentication for PROG5121 QuickChat (Parts 1–3).
 * Validates username, password and South African cell number.
 */
public class Login {

    private String username;
    private String password;
    private String firstName;
    private String lastName;
    private String cellNumber;

    public boolean checkUserName(String username) {
        return username != null
                && username.contains("_")
                && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }
        boolean hasUpper = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasUpper = true;
            } else if (Character.isDigit(c)) {
                hasDigit = true;
            } else if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
        }
        return hasUpper && hasDigit && hasSpecial;
    }

    /**
     * South African cell: starts with 0 followed by 9 digits (e.g. 0831234567)
     * or international form +27 followed by 9 digits.
     */
    public boolean checkCellPhoneNumber(String cell) {
        if (cell == null) {
            return false;
        }
        return cell.matches("0[0-9]{9}") || cell.matches("\\+27[0-9]{9}");
    }

    public String registerUser(String username, String password,
                               String firstName, String lastName, String cellNumber) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
        }
        if (!checkCellPhoneNumber(cellNumber)) {
            return "Cell phone number incorrectly formatted or does not contain an international code, please correct the number and try again.";
        }

        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.cellNumber = cellNumber;

        return "Username successfully captured\nPassword successfully captured\nCell phone number successfully captured";
    }

    public boolean loginUser(String enteredUsername, String enteredPassword) {
        if (this.username == null || this.password == null) {
            return false;
        }
        return this.username.equals(enteredUsername)
                && this.password.equals(enteredPassword);
    }

    public String returnLoginStatus(String enteredUsername, String enteredPassword) {
        if (loginUser(enteredUsername, enteredPassword)) {
            return "Welcome " + firstName + " ," + lastName + " it is great to see you again.";
        }
        return "Username or password incorrect, please try again";
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getUsername() {
        return username;
    }

    public String getCellNumber() {
        return cellNumber;
    }
}
