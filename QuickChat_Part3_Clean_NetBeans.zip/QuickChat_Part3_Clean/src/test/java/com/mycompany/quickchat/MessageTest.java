package com.mycompany.quickchat;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Message class – PROG5121 Part 2/3 style.
 */
public class MessageTest {

    @BeforeEach
    public void setUp() {
        Message.resetCounters();
    }

    // ---------- Recipient cell ----------
    @Test
    public void testCheckRecipientCell_Valid() {
        assertTrue(Message.checkRecipientCell("+27831234567"));
        assertTrue(Message.checkRecipientCell("+27123456789"));
    }

    @Test
    public void testCheckRecipientCell_Invalid() {
        assertFalse(Message.checkRecipientCell("0831234567"));   // missing +
        assertFalse(Message.checkRecipientCell("831234567"));
        assertFalse(Message.checkRecipientCell(null));
    }

    // ---------- Message length ----------
    @Test
    public void testCheckMessageLength_Valid() {
        Message msg = new Message("+27831234567", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Message ready to send.", msg.checkMessageLength());
    }

    @Test
    public void testCheckMessageLength_TooLong() {
        String longText = "A".repeat(260);
        Message msg = new Message("+27831234567", longText);
        String result = msg.checkMessageLength();
        assertTrue(result.contains("Message exceeds 250 characters"));
    }

    @Test
    public void testCheckMessageLength_Empty() {
        Message msg = new Message("+27831234567", "   ");
        assertEquals("Message cannot be empty.", msg.checkMessageLength());
    }

    // ---------- Message Hash ----------
    @Test
    public void testCreateMessageHash_Format() {
        // First message → number 1
        Message msg = new Message("+27831234567", "Hi Mike, can you join us for dinner tonight");
        String hash = msg.getMessageHash();
        // Format: XX:1:HITONIGHT  (first two of ID : number : FIRSTWORDLASTWORD)
        assertTrue(hash.matches("[0-9]{2}:1:HITONIGHT"));
    }

    @Test
    public void testCreateMessageHash_SingleWord() {
        Message msg = new Message("+27831234567", "Hello");
        String hash = msg.getMessageHash();
        assertTrue(hash.endsWith(":HELLOHELLO") || hash.contains("HELLO"));
    }

    // ---------- sentMessage actions ----------
    @Test
    public void testSentMessage_Send() {
        Message msg = new Message("+27831234567", "Test message");
        String result = msg.sentMessage(1);
        assertEquals("Message successfully sent.", result);
        assertEquals("Sent", msg.getStatus());
        assertEquals(1, Message.returnTotalMessages());
    }

    @Test
    public void testSentMessage_Disregard() {
        Message msg = new Message("+27831234567", "Test message");
        String result = msg.sentMessage(2);
        assertEquals("Press 0 to delete message.", result);
        assertEquals("Disregarded", msg.getStatus());
    }

    @Test
    public void testSentMessage_Store() {
        Message msg = new Message("+27831234567", "Test message");
        String result = msg.sentMessage(3);
        assertEquals("Message successfully stored.", result);
        assertEquals("Stored", msg.getStatus());
    }

    // ---------- printMessages ----------
    @Test
    public void testPrintMessages_ContainsRequiredFields() {
        Message msg = new Message("+27831234567", "Hello world");
        msg.sentMessage(1);
        String printed = msg.printMessages();
        assertTrue(printed.contains("Message ID:"));
        assertTrue(printed.contains("Message Hash:"));
        assertTrue(printed.contains("Recipient: +27831234567"));
        assertTrue(printed.contains("Message: Hello world"));
        assertTrue(printed.contains("Status: Sent"));
    }

    // ---------- Message ID is 10 digits ----------
    @Test
    public void testMessageId_IsTenDigits() {
        Message msg = new Message("+27831234567", "Test");
        assertEquals(10, msg.getMessageId().length());
        assertTrue(msg.getMessageId().matches("[0-9]{10}"));
    }
}
