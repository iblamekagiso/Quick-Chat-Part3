package com.mycompany.quickchat;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Represents a single chat message for PROG5121 QuickChat Parts 2 & 3.
 * Handles Message ID, recipient validation, length check, hash, and send/store/disregard.
 */
public class Message {

    private final String messageId;       // 10-digit unique ID
    private final int messageNumber;      // auto number (1, 2, 3...)
    private final String recipient;
    private final String messageText;
    private final String messageHash;
    private String status;                // "Sent", "Stored", "Disregarded"

    private static int totalMessagesSent = 0;
    private static int messageCounter = 0;

    public Message(String recipient, String messageText) {
        messageCounter++;
        this.messageNumber = messageCounter;
        this.messageId = generateMessageId();
        this.recipient = recipient;
        this.messageText = messageText == null ? "" : messageText;
        this.messageHash = createMessageHash();
        this.status = "Created";
    }

    /** Generates a random 10-digit Message ID as required by the brief. */
    private String generateMessageId() {
        long id = ThreadLocalRandom.current().nextLong(1_000_000_000L, 10_000_000_000L);
        return String.valueOf(id);
    }

    /**
     * Recipient must start with + and be 10–15 digits after the + (international format).
     */
    public static boolean checkRecipientCell(String number) {
        if (number == null) {
            return false;
        }
        return number.matches("^\\+[0-9]{10,15}$");
    }

    /**
     * Message text must not exceed 250 characters.
     * @return "Message ready to send." or an error message
     */
    public String checkMessageLength() {
        if (messageText.length() > 250) {
            int excess = messageText.length() - 250;
            return "Message exceeds 250 characters by " + excess + ", please reduce size.";
        }
        if (messageText.trim().isEmpty()) {
            return "Message cannot be empty.";
        }
        return "Message ready to send.";
    }

    /**
     * Hash format: first two digits of Message ID : message number : FIRSTWORDLASTWORD (all caps)
     * Example: 00:0:HITONIGHT
     */
    public String createMessageHash() {
        String idPart = messageId.length() >= 2
                ? messageId.substring(0, 2)
                : messageId;

        String[] words = messageText.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;

        // Remove non-letters for clean hash
        firstWord = firstWord.replaceAll("[^a-zA-Z]", "");
        lastWord = lastWord.replaceAll("[^a-zA-Z]", "");

        return (idPart + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    /**
     * Process user choice: 1 = Send, 2 = Disregard, 3 = Store
     */
    public String sentMessage(int choice) {
        switch (choice) {
            case 1:
                this.status = "Sent";
                totalMessagesSent++;
                return "Message successfully sent.";
            case 2:
                this.status = "Disregarded";
                return "Press 0 to delete message.";
            case 3:
                this.status = "Stored";
                return "Message successfully stored.";
            default:
                return "Invalid option.";
        }
    }

    public String printMessages() {
        return "Message ID: " + messageId
                + "\nMessage Hash: " + messageHash
                + "\nRecipient: " + recipient
                + "\nMessage: " + messageText
                + "\nStatus: " + status;
    }

    public static int returnTotalMessages() {
        return totalMessagesSent;
    }

    // ========== Getters ==========
    public String getMessageId() {
        return messageId;
    }

    public int getMessageNumber() {
        return messageNumber;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getStatus() {
        return status;
    }

    /** Reset counters (for unit tests). */
    public static void resetCounters() {
        totalMessagesSent = 0;
        messageCounter = 0;
    }
}
