package com.mycompany.quickchat;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

/**
 * Unit tests for MessageStorage – PROG5121 Part 3.
 */
public class MessageStorageTest {

    @BeforeEach
    public void setUp() {
        Message.resetCounters();
        MessageStorage.initializeStorage();
    }

    @Test
    public void testStoreMessage_Sent() {
        Message msg = new Message("+27831234567", "Hello");
        msg.sentMessage(1);
        MessageStorage.storeMessage(msg, 1);
        assertEquals(1, MessageStorage.getSentMessages().size());
        assertEquals(0, MessageStorage.getStoredMessages().size());
    }

    @Test
    public void testStoreMessage_Stored() {
        Message msg = new Message("+27831234567", "Store me");
        msg.sentMessage(3);
        MessageStorage.storeMessage(msg, 3);
        assertEquals(1, MessageStorage.getStoredMessages().size());
    }

    @Test
    public void testStoreMessage_Disregarded() {
        Message msg = new Message("+27831234567", "Ignore me");
        msg.sentMessage(2);
        MessageStorage.storeMessage(msg, 2);
        assertEquals(1, MessageStorage.getDisregardedMessages().size());
    }

    @Test
    public void testSearchByMessageId_Found() {
        Message msg = new Message("+27831234567", "Find me");
        msg.sentMessage(1);
        MessageStorage.storeMessage(msg, 1);

        Message found = MessageStorage.searchByMessageId(msg.getMessageId());
        assertNotNull(found);
        assertEquals(msg.getMessageId(), found.getMessageId());
    }

    @Test
    public void testSearchByMessageId_NotFound() {
        Message found = MessageStorage.searchByMessageId("0000000000");
        assertNull(found);
    }

    @Test
    public void testSearchByRecipient() {
        Message m1 = new Message("+27831111111", "One");
        Message m2 = new Message("+27832222222", "Two");
        Message m3 = new Message("+27831111111", "Three");
        m1.sentMessage(1);
        m2.sentMessage(1);
        m3.sentMessage(3);
        MessageStorage.storeMessage(m1, 1);
        MessageStorage.storeMessage(m2, 1);
        MessageStorage.storeMessage(m3, 3);

        List<Message> results = MessageStorage.searchByRecipient("+27831111111");
        assertEquals(2, results.size());
    }

    @Test
    public void testDeleteByHash() {
        Message msg = new Message("+27831234567", "Delete me");
        msg.sentMessage(1);
        MessageStorage.storeMessage(msg, 1);

        boolean deleted = MessageStorage.deleteByHash(msg.getMessageHash());
        assertTrue(deleted);
        assertEquals(0, MessageStorage.getSentMessages().size());
    }

    @Test
    public void testDeleteByHash_NotFound() {
        boolean deleted = MessageStorage.deleteByHash("XX:0:FAKE");
        assertFalse(deleted);
    }

    @Test
    public void testDisplayLongestMessage() {
        Message shortMsg = new Message("+27831111111", "Hi");
        Message longMsg = new Message("+27832222222", "This is a much longer message for testing");
        shortMsg.sentMessage(1);
        longMsg.sentMessage(1);
        MessageStorage.storeMessage(shortMsg, 1);
        MessageStorage.storeMessage(longMsg, 1);

        String report = MessageStorage.displayLongestMessage();
        assertTrue(report.contains("This is a much longer message for testing"));
    }

    @Test
    public void testDisplayFullReport_ContainsSummary() {
        Message msg = new Message("+27831234567", "Report test");
        msg.sentMessage(1);
        MessageStorage.storeMessage(msg, 1);

        String report = MessageStorage.displayFullReport("Kyle Smith");
        assertTrue(report.contains("FULL MESSAGE REPORT"));
        assertTrue(report.contains("Total Sent: 1"));
        assertTrue(report.contains("Kyle Smith"));
    }

    @Test
    public void testGetRecentMessages_Empty() {
        String result = MessageStorage.getRecentMessages();
        assertEquals("No recently sent messages.", result);
    }
}
