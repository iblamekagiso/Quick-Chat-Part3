package com.mycompany.quickchat;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Login class – PROG5121 style.
 */
public class LoginTest {

    private Login login;

    @BeforeEach
    public void setUp() {
        login = new Login();
    }

    // ---------- Username ----------
    @Test
    public void testCheckUserName_Correct() {
        assertTrue(login.checkUserName("kyl_1"));
    }

    @Test
    public void testCheckUserName_Incorrect() {
        assertFalse(login.checkUserName("kyle!!!!!!!"));
    }

    // ---------- Password ----------
    @Test
    public void testCheckPasswordComplexity_Correct() {
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    public void testCheckPasswordComplexity_Incorrect() {
        assertFalse(login.checkPasswordComplexity("password"));
    }

    // ---------- Cell phone ----------
    @Test
    public void testCheckCellPhoneNumber_LocalValid() {
        assertTrue(login.checkCellPhoneNumber("0831234567"));
    }

    @Test
    public void testCheckCellPhoneNumber_InternationalValid() {
        assertTrue(login.checkCellPhoneNumber("+27831234567"));
    }

    @Test
    public void testCheckCellPhoneNumber_Invalid() {
        assertFalse(login.checkCellPhoneNumber("831234567"));
        assertFalse(login.checkCellPhoneNumber("abc"));
    }

    // ---------- registerUser ----------
    @Test
    public void testRegisterUser_Success() {
        String result = login.registerUser("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith", "0831234567");
        assertTrue(result.contains("Username successfully captured"));
        assertTrue(result.contains("Password successfully captured"));
        assertTrue(result.contains("Cell phone number successfully captured"));
    }

    @Test
    public void testRegisterUser_BadUsername() {
        String result = login.registerUser("kyle!!!!!!!", "Ch&&sec@ke99!", "Kyle", "Smith", "0831234567");
        assertTrue(result.contains("Username is not correctly formatted"));
    }

    @Test
    public void testRegisterUser_BadPassword() {
        String result = login.registerUser("kyl_1", "password", "Kyle", "Smith", "0831234567");
        assertTrue(result.contains("Password is not correctly formatted"));
    }

    // ---------- loginUser / returnLoginStatus ----------
    @Test
    public void testLoginUser_Success() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith", "0831234567");
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLoginUser_Failed() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith", "0831234567");
        assertFalse(login.loginUser("wrong", "wrong"));
    }

    @Test
    public void testReturnLoginStatus_Success() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith", "0831234567");
        String msg = login.returnLoginStatus("kyl_1", "Ch&&sec@ke99!");
        assertEquals("Welcome Kyle ,Smith it is great to see you again.", msg);
    }

    @Test
    public void testReturnLoginStatus_Failed() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith", "0831234567");
        String msg = login.returnLoginStatus("wrong", "wrong");
        assertEquals("Username or password incorrect, please try again", msg);
    }
}
