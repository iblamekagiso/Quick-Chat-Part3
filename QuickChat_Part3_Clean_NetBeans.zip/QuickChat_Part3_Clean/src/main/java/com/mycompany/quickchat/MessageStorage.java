package com.mycompany.quickchat;

import java.util.ArrayList;
import java.util.List;

/**
 * Stores sent, stored and disregarded messages in arrays/lists (Part 3 requirement).
 * Provides search, delete and report functionality.
 */
public class MessageStorage {

    private static final List<Message> sentMessages = new ArrayList<>();
    private static final List<Message> storedMessages = new ArrayList<>();
    private static final List<Message> disregardedMessages = new ArrayList<>();

    public static void initializeStorage() {
        sentMessages.clear();
        storedMessages.clear();
        disregardedMessages.clear();
    }

    /**
     * Places a message into the correct list based on action:
     * 1 = Sent, 2 = Disregarded, 3 = Stored
     */
    public static void storeMessage(Message msg, int action) {
        switch (action) {
            case 1 -> sentMessages.add(msg);
            case 2 -> disregardedMessages.add(msg);
            case 3 -> storedMessages.add(msg);
            default -> {
                // ignore invalid
            }
        }
    }

    public static String getRecentMessages() {
        if (sentMessages.isEmpty()) {
            return "No recently sent messages.";
        }
        StringBuilder sb = new StringBuilder("Recently sent messages:\n\n");
        for (Message m : sentMessages) {
            sb.append(m.printMessages()).append("\n---\n");
        }
        return sb.toString();
    }

    public static Message searchByMessageId(String id) {
        for (Message m : sentMessages) {
            if (m.getMessageId().equals(id)) {
                return m;
            }
        }
        for (Message m : storedMessages) {
            if (m.getMessageId().equals(id)) {
                return m;
            }
        }
        for (Message m : disregardedMessages) {
            if (m.getMessageId().equals(id)) {
                return m;
            }
        }
        return null;
    }

    public static List<Message> searchByRecipient(String recipient) {
        List<Message> results = new ArrayList<>();
        for (Message m : sentMessages) {
            if (m.getRecipient().equals(recipient)) {
                results.add(m);
            }
        }
        for (Message m : storedMessages) {
            if (m.getRecipient().equals(recipient)) {
                results.add(m);
            }
        }
        for (Message m : disregardedMessages) {
            if (m.getRecipient().equals(recipient)) {
                results.add(m);
            }
        }
        return results;
    }

    public static boolean deleteByHash(String hash) {
        boolean removed = sentMessages.removeIf(m -> m.getMessageHash().equals(hash));
        removed |= storedMessages.removeIf(m -> m.getMessageHash().equals(hash));
        removed |= disregardedMessages.removeIf(m -> m.getMessageHash().equals(hash));
        return removed;
    }

    public static String displaySenderRecipient(String senderName) {
        if (sentMessages.isEmpty()) {
            return "No sent messages to display.";
        }
        StringBuilder sb = new StringBuilder("Sender and Recipient of all sent messages:\n\n");
        for (Message m : sentMessages) {
            sb.append("From: ").append(senderName)
              .append("\nTo: ").append(m.getRecipient())
              .append("\n---\n");
        }
        return sb.toString();
    }

    public static String displayLongestMessage() {
        if (sentMessages.isEmpty()) {
            return "No sent messages.";
        }
        Message longest = sentMessages.get(0);
        for (Message m : sentMessages) {
            if (m.getMessageText().length() > longest.getMessageText().length()) {
                longest = m;
            }
        }
        return "Longest sent message:\n"
                + "ID: " + longest.getMessageId() + "\n"
                + "Recipient: " + longest.getRecipient() + "\n"
                + "Length: " + longest.getMessageText().length() + " characters\n"
                + "Message: " + longest.getMessageText();
    }

    public static String displayFullReport(String senderName) {
        if (sentMessages.isEmpty() && storedMessages.isEmpty() && disregardedMessages.isEmpty()) {
            return "No messages to report.";
        }
        StringBuilder sb = new StringBuilder("FULL MESSAGE REPORT\n===================\n\n");

        for (Message m : sentMessages) {
            sb.append("Status: Sent\n")
              .append("Message ID: ").append(m.getMessageId()).append("\n")
              .append("Hash: ").append(m.getMessageHash()).append("\n")
              .append("Sender: ").append(senderName).append("\n")
              .append("Recipient: ").append(m.getRecipient()).append("\n")
              .append("Message: ").append(m.getMessageText()).append("\n")
              .append("------------------------\n");
        }
        for (Message m : storedMessages) {
            sb.append("Status: Stored\n")
              .append("Message ID: ").append(m.getMessageId()).append("\n")
              .append("Hash: ").append(m.getMessageHash()).append("\n")
              .append("Sender: ").append(senderName).append("\n")
              .append("Recipient: ").append(m.getRecipient()).append("\n")
              .append("Message: ").append(m.getMessageText()).append("\n")
              .append("------------------------\n");
        }

        sb.append("\nSUMMARY:\n")
          .append("Total Sent: ").append(sentMessages.size()).append("\n")
          .append("Total Stored: ").append(storedMessages.size()).append("\n")
          .append("Total Disregarded: ").append(disregardedMessages.size()).append("\n");

        return sb.toString();
    }

    // Getters for testing
    public static List<Message> getSentMessages() {
        return sentMessages;
    }

    public static List<Message> getStoredMessages() {
        return storedMessages;
    }

    public static List<Message> getDisregardedMessages() {
        return disregardedMessages;
    }
}
